<?php
class Admin extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->model('Madmin');
        if($this->session->userdata('status') != "login"){
            redirect('login/index');
        }
    } 
    function index(){
        $data['admin'] = $this->Madmin->get_all_admin();
        $data['_view'] = 'admin/index';
        $this->load->view('layouts',$data);
    }
    function add(){
		$data['admin'] = $this->Madmin->get_all_admin();

        if(isset($_POST) && count($_POST) > 0){
            $params = array(
				'nama' => $this->input->post('nama'),
				'username' => $this->input->post('username'),
				'password' => $this->encryption->encrypt($this->input->post('password'))
			);
			$id = $this->Madmin->add_admin($params);
			redirect('admin/index');
        }
        else{            
            $data['_view'] = 'admin/add';
            $this->load->view('layouts',$data);
        }
    }  
    function edit($id){
        $data['admin'] = $this->Madmin->get_admin($id);
        if(isset($data['admin']['id'])){
            if(isset($_POST) && count($_POST) > 0){
				$params = array(
					'nama' => $this->input->post('nama'),
					'username' => $this->input->post('username'),
					'password' => $this->encryption->encrypt($this->input->post('password'))
                );
                $id = $this->Madmin->update_admin($id, $params);
                redirect('admin/index');
            }
            else{
                $data['_view'] = 'admin/edit';
                $this->load->view('layouts',$data);
            }
        }
        else
            show_error('Data Gagal Diperbarui');
    } 
    function remove($id){ 
        $admin = $this->Madmin->get_admin($id);
        if(isset($admin['id'])){
            $this->Madmin->delete_admin($id);
            redirect('admin/index');
        }
        else
            show_error('Data Gagal Dihapus');
    }
}
