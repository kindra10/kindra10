<?php
class Kategori extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->model('Mkategori');
        if($this->session->userdata('status') != "login"){
            redirect('login/index');
        }
    } 
    function index(){
        $data['kategori'] = $this->Mkategori->get_all_kategori();
        $data['_view'] = 'kategori/index';
        $this->load->view('layouts',$data);
    }
    function add(){
		$data['kategori'] = $this->Mkategori->get_all_kategori();

        if(isset($_POST) && count($_POST) > 0){
            $params = array(
				'nama_kategori' => $this->input->post('nama_kategori')
			);
			$id_kategori = $this->Mkategori->add_kategori($params);
			redirect('kategori/index');
        }
        else{            
            $data['_view'] = 'kategori/add';
            $this->load->view('layouts',$data);
        }
    }  
    function edit($id_kategori){
        $data['kategori'] = $this->Mkategori->get_kategori($id_kategori);
        if(isset($data['kategori']['id_kategori'])){
            if(isset($_POST) && count($_POST) > 0){
				$params = array(
                	'nama_kategori' => $this->input->post('nama_kategori')
                );
                $id_kategori = $this->Mkategori->update_kategori($id_kategori, $params);
                redirect('kategori/index');
            }
            else{
                $data['_view'] = 'kategori/edit';
                $this->load->view('layouts',$data);
            }
        }
        else
            show_error('Data Gagal Diperbarui');
    } 
    function remove($id_kategori){ 
        $kategori = $this->Mkategori->get_kategori($id_kategori);
        if(isset($kategori['id_kategori'])){
            $this->Mkategori->delete_kategori($id_kategori);
            redirect('kategori/index');
        }
        else
            show_error('Data Gagal Dihapus');
    }
}
