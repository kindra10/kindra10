<?php
class Login extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model('Mlogin');
        $this->load->library('encryption');
	} 
	function index(){
        $this->load->view('login');
    }
    function aksi_login()
	{
		$username = $this->security->xss_clean($this->input->post('username'));
		$password = $this->security->xss_clean($this->input->post('password'));
		$data = $this->Mlogin->cek_login($username);
		$pass = $this->encryption->decrypt($data['password']);
		if ($password == $pass) {
				$data_session = array(
					'username' => $username,
					'status' => "login",
					'nama' => $data['nama'],
					'id' => $data['id'],
				);
				$this->session->set_userdata($data_session);
				redirect('dashboard');
            } else{
				echo "<script>window.alert('Password salah, silahkan cek kembali'); location.href='".site_url('login')."'</script>";
			}
		}
	function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url('login'));
	}
}