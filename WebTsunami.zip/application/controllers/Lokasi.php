<?php
class Lokasi extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->model('Mlokasi');
        $this->load->model('Mkategori');
        if($this->session->userdata('status') != "login"){
            redirect('login/index');
        }
	} 
	
    function index(){
        $data['lokasi'] = $this->Mlokasi->get_all_lokasi();
        $data['_view'] = 'lokasi/index';
        $this->load->view('layouts',$data);
	}
	
	function getLokasiAPI(){
        $data['lokasi'] = $this->Mlokasi->get_all_lokasi();
        $this->load->view('lokasi/api',$data);
	}
	
	function getJarak(){
        $this->load->view('lokasi/jarak',$data);
	}
	
    function add(){
		$data['lokasi'] = $this->Mlokasi->get_all_lokasi();
		$data['kategori'] = $this->Mkategori->get_all_kategori();

        if(isset($_POST) && count($_POST) > 0){
            $config['upload_path']          = 'public/images/';
            $config['allowed_types']        = 'jpg|png';
            $config['max_size']             = 10000;
            $config['max_width']            = 3000;
            $config['max_height']           = 1688;
            $this->load->library('upload', $config);
            if ( ! $this->upload->do_upload('foto')){
                echo '<script>alert("Data gagal disimpan");</script>';
                redirect('lokasi/index');
            }
            else{
                $file = $this->upload->data();
                $foto = $file['file_name'];
                $params = array(
                    'id_lokasi' => $this->input->post('id_lokasi'),
                    'nama_lokasi' => $this->input->post('nama_lokasi'),
                    'latitude' => $this->input->post('latitude'),
                    'longitude' => $this->input->post('longitude'),
                    'alamat' => $this->input->post('alamat'),
                    'jumlah_lantai' => $this->input->post('jumlah_lantai'),
                    'kapasitas' => $this->input->post('kapasitas'),
                    'keterangan' => $this->input->post('keterangan'),
                    'gambar' => $foto,
                    'id_kategori' => $this->input->post('id_kategori')
                );
                $id_lokasi = $this->Mlokasi->add_lokasi($params);
                redirect('lokasi/index');
            }
        }
        else{            
            $data['_view'] = 'lokasi/add';
            $this->load->view('layouts',$data);
        }
    }  
    function edit($id_lokasi){
        $data['lokasi'] = $this->Mlokasi->get_lokasi($id_lokasi);
		$data['kategori'] = $this->Mkategori->get_all_kategori();
		
        if(isset($data['lokasi']['id_lokasi'])){
            if(isset($_POST) && count($_POST) > 0){
                $config['upload_path']          = 'public/images/';
                $config['allowed_types']        = 'jpg|png';
                $config['max_size']             = 10000;
                $config['max_width']            = 3000;
                $config['max_height']           = 1688;
                $this->load->library('upload', $config);
                if ( $this->upload->do_upload('gambar')){
                    $file = $this->upload->data();
                    $foto = $file['file_name'];
                    $params = array(
                        'nama_lokasi' => $this->input->post('nama_lokasi'),
                        'latitude' => $this->input->post('latitude'),
                        'longitude' => $this->input->post('longitude'),
                        'alamat' => $this->input->post('alamat'),
                        'jumlah_lantai' => $this->input->post('jumlah_lantai'),
                        'kapasitas' => $this->input->post('kapasitas'),
                        'keterangan' => $this->input->post('keterangan'),
                        'gambar' => $foto,
                        'id_kategori' => $this->input->post('id_kategori')
                    );
                    $id_lokasi = $this->Mlokasi->update_lokasi($id_lokasi, $params);
                    redirect('lokasi/index');
                }
                else{
                    $params = array(
                        'nama_lokasi' => $this->input->post('nama_lokasi'),
                        'latitude' => $this->input->post('latitude'),
                        'longitude' => $this->input->post('longitude'),
                        'alamat' => $this->input->post('alamat'),
                        'jumlah_lantai' => $this->input->post('jumlah_lantai'),
                        'kapasitas' => $this->input->post('kapasitas'),
                        'keterangan' => $this->input->post('keterangan'),
                        'id_kategori' => $this->input->post('id_kategori')
                    );
                    $id_lokasi = $this->Mlokasi->update_lokasi($id_lokasi, $params);
                    redirect('lokasi/index');
                }
            }
            else{
                $data['_view'] = 'lokasi/edit';
                $this->load->view('layouts',$data);
            }
        }
        else
            show_error('Data Gagal Diperbarui');
	}
	
    function remove($id_lokasi){ 
        $lokasi = $this->Mlokasi->get_lokasi($id_lokasi);
        if(isset($lokasi['id_lokasi'])){
            $path = "./public/images/";
            unlink($path.$lokasi['gambar']);
            
            $this->Mlokasi->delete_lokasi($id_lokasi);
            redirect('lokasi/index');
        }
        else
            show_error('Data Gagal Dihapus');
	}
	
	function laporan(){
        $data['lokasi'] = $this->Mlokasi->get_all_lokasi();
        $this->load->view('lokasi/laporan',$data);
    }
}
