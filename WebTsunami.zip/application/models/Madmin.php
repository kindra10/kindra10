<?php
class Madmin extends CI_Model{
    function __construct(){
        parent::__construct();
    }
    function get_admin($id){
        return $this->db->get_where('admin',array('id'=>$id))->row_array();
    }
    function get_all_admin(){
        $this->db->order_by('id','asc');
        return $this->db->get('admin')->result_array();
    }
    function add_admin($params){
        $this->db->insert('admin',$params);
        return $this->db->insert_id();
    }
    function update_admin($id,$params){
        $this->db->where('id',$id);
        return $this->db->update('admin',$params);
    }
    function delete_admin($admin){
		$this->db->where('id',$admin);
        return $this->db->delete('admin');
    }
}
