<?php
class Mkategori extends CI_Model{
    function __construct(){
        parent::__construct();
    }
    function get_kategori($id_kategori){
        return $this->db->get_where('kategori',array('id_kategori'=>$id_kategori))->row_array();
    }
    function get_all_kategori(){
        $this->db->order_by('id_kategori','asc');
        return $this->db->get('kategori')->result_array();
    }
    function add_kategori($params){
        $this->db->insert('kategori',$params);
        return $this->db->insert_id();
    }
    function update_kategori($id_kategori,$params){
        $this->db->where('id_kategori',$id_kategori);
        return $this->db->update('kategori',$params);
    }
    function delete_kategori($kategori){
		$this->db->where('id_kategori',$kategori);
        return $this->db->delete('kategori');
    }
}
