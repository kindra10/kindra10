<?php
class Mlokasi extends CI_Model{
    function __construct(){
        parent::__construct();
    }
    function get_lokasi($id_lokasi){
        return $this->db->get_where('lokasi',array('id_lokasi'=>$id_lokasi))->row_array();
    }
    function get_all_lokasi(){
        $this->db->order_by('id_lokasi','asc');
        return $this->db->get('lokasi')->result_array();
    }
    function add_lokasi($params){
        $this->db->insert('lokasi',$params);
        return $this->db->insert_id();
    }
    function update_lokasi($id_lokasi,$params){
        $this->db->where('id_lokasi',$id_lokasi);
        return $this->db->update('lokasi',$params);
    }
    function delete_lokasi($lokasi){
		$this->db->where('id_lokasi',$lokasi);
        return $this->db->delete('lokasi');
    }
}
