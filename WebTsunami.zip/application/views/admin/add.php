<div class="page-title">
	<div>
		<h1><i class="fa fa-edit"></i> Form Tambah Admin</h1>
		<ul class="breadcrumb side">
			<li><i class="fa fa-home fa-lg"></i></li>
			<li>Admin</li>
			<li class="active"><a href="#">Tambah</a></li>
		</ul>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<form action="<?php echo site_url('admin/add') ?>" method="POST">
				<h3 class="card-title">Tambah</h3>
				<div class="card-body">
				    <div class="col-md-6">
						<div class="form-group">
							<label class="control-label">Username</label>
							<input class="form-control" type="text" name="username" placeholder="Username">
						</div>
					</div><div class="col-md-6">
						<div class="form-group">
							<label class="control-label">Password</label>
							<input class="form-control" type="password" name="password" placeholder="Password">
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label class="control-label">Nama</label>
							<input class="form-control" type="text" name="nama" placeholder="Nama">
						</div>
					</div>
					<div>
						<button type="submit" name="simpan" class="btn btn-success">Simpan</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
