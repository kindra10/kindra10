<div class="page-title">
	<div>
		<h1>List Admin</h1>
		<ul class="breadcrumb side">
			<li><i class="fa fa-home fa-lg"></i></li>
			<li>Admin</li>
			<li class="active"><a href="#">list</a></li>
		</ul>
	</div>

	<div>
		<!-- <a class="btn btn-default btn-flat" href="#">Cetak</a> -->
		<a class="btn btn-info btn-flat" href="<?php echo site_url('admin/add') ?>"><i class="fa fa-lg fa-plus"></i></a>
	</div>
</div>

<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
				<table class="table table-hover table-bordered" id="sampleTable">
					<thead>
						<tr>
							<td align="center">No</th>
							<td align="center">Nama</td>
							<td align="center">Username</td>
							<td align="center"><i class="fa fa-cog fa-fw"></i></td>
						</tr>
					</thead>
					<tbody>
						<?php
						$i = 1;
						foreach ($admin as $data){ ?>
						<tr>
							<td align="center"><?php echo $i; ?></td>
							<td><?php echo $data['nama']; ?></td>
							<td><?php echo $data['username']; ?></td>
							<td align="center">
								<a href="<?php echo site_url('admin/edit/').$data['id'] ?>"
									class="label label-success"><i class="fa fa-pencil-square-o"></i></a>
								<a onclick="if(confirm('Apakah anda yakin ingin menghapus data ini ??')){ location.href='<?php echo site_url('admin/remove/').$data['id'] ?>' }"
									class="label label-danger"><i class="fa fa-trash-o fa-fw"></i></a>
							</td>
						</tr>
						<?php $i++; }?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
