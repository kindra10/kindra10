<div class="page-title">
	<div>
		<h1><i class="fa fa-dashboard"></i> Dashboard</h1>
	</div>
</div>
<div class="row">
	<div class="col-md-4">
		<div class="widget-small primary"><i class="icon fa fa-users fa-3x"></i>
			<div class="info">
				<h4>Admin</h4>
				<p><b><?php echo $this->db->query("SELECT id FROM admin")->num_rows(); ?></b></p>
			</div>
		</div>
	</div>
	<div class="col-md-4">
		<div class="widget-small warning"><i class="icon fa fa-files-o fa-3x"></i>
			<div class="info">
				<h4>Peta Lokasi</h4>
				<p><b><?php echo $this->db->query("SELECT id_lokasi FROM lokasi")->num_rows(); ?></b></p>
			</div>
		</div>
	</div>
	<div class="col-md-4">
		<div class="widget-small danger"><i class="icon fa fa-star fa-3x"></i>
			<div class="info">
				<h4>Kategori</h4>
				<p><b><?php echo $this->db->query("SELECT id_kategori FROM kategori")->num_rows(); ?></b></p>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-body" style="min-height: 350px;">
				<h2><i>Selamat datang</i> <small> di halaman utama Administrator</small></h2>
			</div>
		</div>
	</div>
</div>
