<div class="page-title">
	<div>
		<h1><i class="fa fa-edit"></i> Form Edit Kategori</h1>
		<ul class="breadcrumb side">
			<li><i class="fa fa-home fa-lg"></i></li>
			<li>Kategori</li>
			<li class="active"><a href="#">Edit</a></li>
		</ul>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<form action="<?php echo site_url('kategori/edit/').$kategori['id_kategori'] ?>" method="POST">
				<h3 class="card-title">Edit</h3>
				<div class="card-body">
					<div>
						<div class="form-group">
							<label class="control-label">Nama Kategori</label>
							<input class="form-control" type="text" name="nama_kategori" placeholder="Nama Kategori" value="<?php echo $kategori['nama_kategori'] ?>">
						</div>
					</div>
					<div>
						<button type="submit" name="simpan" class="btn btn-success">Simpan</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
