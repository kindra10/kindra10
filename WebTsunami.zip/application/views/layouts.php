<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/admin/vali/dist/css/main.css');?>">
	<link rel="stylesheet" type="text/css" href="<?php echo site_url('assets/admin/vali/dist/css/fontawesom.css');?>">
	<link rel="stylesheet" type="text/css"
		href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Shelter Tsunami</title>
	<link rel="shortcut icon" href="<?php echo site_url('assets/img/favicon.png');?>">
</head>

<body class="sidebar-mini fixed">
	<div class="wrapper">
		<header class="main-header hidden-print"><a class="logo" href="#">Shelter Tsunami</a>
			<nav class="navbar navbar-static-top"><a class="sidebar-toggle" href="#" data-toggle="offcanvas"></a>
				<div class="navbar-custom-menu">
					<ul class="top-nav">
						<li class="dropdown"><a class="dropdown-toggle" href="#" data-toggle="dropdown" role="button"
								aria-haspopup="true" aria-expanded="false"> <b>
									<?php echo $this->session->userdata('nama')?></b> <i
									class="fa fa-user fa-lg"></i></a>
						</li>
					</ul>
				</div>
			</nav>
		</header>
		<aside class="main-sidebar hidden-print">
			<section class="sidebar">
				<div class="user-panel">
					<div class="pull-left image"><img class="img-circle"
							src="<?php echo site_url('assets/img/o.jpg');?>"></div>
					<div class="pull-left info">
						<p><?php echo $this->session->userdata('nama') ?></p>
					</div>
				</div>
				<ul class="sidebar-menu">
					<li><a href="<?php echo site_url('dashboard');?>"><i
								class="fa fa-dashboard"></i><span>Dashboard</span></a></li>
					<li><a href="<?php echo site_url('lokasi');?>"><i class="fa fa-map-marker"></i><span>Peta
								Lokasi</span></a></li>
					<li><a href="<?php echo site_url('kategori');?>"><i class="fa fa-star"></i><span>Kategori</span></a>
					</li>
					<li><a href="<?php echo site_url('admin');?>"><i class="fa fa-user fa-lg"></i><span>Admin</span></a>
					</li>
					<li><a href="<?php echo site_url('login/logout');?>"><i
								class="fa fa-sign-out fa-lg"></i><span>Logout</span></a></li>
				</ul>
			</section>
		</aside>
		<!-- Content Wrapper. Contains page content -->
		<div class="content-wrapper">
			<?php if(isset($_view) && $_view) $this->load->view($_view); ?>
		</div>
	</div>
	<script src="<?php echo site_url('assets/admin/vali/dist/js/jquery-2.1.4.min.js');?>"></script>
	<script src="<?php echo site_url('assets/admin/vali/dist/js/bootstrap.min.js');?>"></script>
	<script src="<?php echo site_url('assets/admin/vali/dist/js/plugins/pace.min.js');?>"></script>
	<script src="<?php echo site_url('assets/admin/vali/dist/js/main.js');?>"></script>
	<script type="text/javascript"
		src="<?php echo site_url('assets/admin/vali/dist/js/plugins/jquery.dataTables.min.js');?>"></script>
	<script type="text/javascript"
		src="<?php echo site_url('assets/admin/vali/dist/js/plugins/dataTables.bootstrap.min.js');?>"></script>
	<script type="text/javascript">
		$('#sampleTable').DataTable();
	</script>

</body>

</html>
