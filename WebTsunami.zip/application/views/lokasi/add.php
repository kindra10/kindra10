<div class="page-title">
	<div>
		<h1>Maps Lokasi</h1>
		<ul class="breadcrumb side">
			<li><i class="fa fa-home fa-lg"></i></li>
			<li>lokasi</li>
			<li class="active"><a href="#">list</a></li>
		</ul>
	</div>

    <div>
	<a class="btn btn-primary btn-flat" href="<?php echo site_url('lokasi') ?>"><i class="fa fa-lg fa-list"></i></a>
	</div>
</div>

<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
			    <input id="pac-input" style="width: 50%; margin-top: 1%; height: 7%;" class="controls" type="text" placeholder="Search Box">
				<div id="map_canvas" style="width: 100%;height: 500px;">
				</div>
            </div>
		</div>
	</div>
</div>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCSJd_VTORs8XcQpePIELLO0n27w_Zvzzo&libraries=places&callback=initAutocomplete"></script>


<script type="text/javascript">  
  var infowindow = null;      
    
    function initialize() {  
        // Baris berikut digunakan untuk mengisi marker atau tanda titik di peta  
        var sites = [  
        
        <?php
        $i = 1;
        foreach ($lokasi as $data) {
        ?>
        
         ["<?php echo $data['nama_lokasi']; ?>",<?php echo $data['latitude']; ?> , <?php echo $data['longitude']; ?> , <?php echo $i; ?> , "<h4><?php echo $data['nama_lokasi']; ?></h4><p><?php echo $data['alamat'];?><p><?php echo $data['jumlah_lantai'];?><p><?php echo $data['kapasitas'];?><p><?php echo $data['keterangan']; ?></p>"], // pertama merupakan judul market, kedua adalah titik koordinan latitude, ketiga longitude, dan keempat merupakan z index (titik mana yang ditampilkan lebih dulu) untuk menentukan titik mana diatas titik mana, ketiga merupakan isi keterangan marker nya.  
                 
        <?php $i++; } ?>
        ];  
        var centerMap = new google.maps.LatLng(-0.9217171,100.3616693); // mengatur pusat peta  
          
        var myOptions = {  
            zoom: 15, // level zoom peta  
            center: centerMap, // setting pusat peta ke centerMap  
            mapTypeId: google.maps.MapTypeId.roadmap //menentukan tipe peta  
        }  
    
        var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions); //menempatkan peta pada div dengan ID map_canvas di html
        
        // Membuat Kotak pencarian terhubung dengan tampilan map
        var input = document.getElementById('pac-input');
        var searchBox = new google.maps.places.SearchBox(input);
        map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

        map.addListener('bounds_changed', function() {
          searchBox.setBounds(map.getBounds());
        });

        var markersauto = [];
        // Mengaktifkan detail pada suatu tempat ketika pengguna
        // memilih salah satu dari daftar prediksi tempat 
        searchBox.addListener('places_changed', function() {
          var places = searchBox.getPlaces();

          if (places.length == 0) {
            return;
          }

          // menghilangkan marker tempat sebelumnya
          markersauto.forEach(function(marker) {
            marker.setMap(null);
          });
          markersauto = [];

          // Untuk setiap tempat, dapatkan icon, nama dan tempat.
          var bounds = new google.maps.LatLngBounds();
          places.forEach(function(place) {
            if (!place.geometry) {
              console.log("Returned place contains no geometry");
              return;
            }
            var icon = {
              url: place.icon,
              size: new google.maps.Size(71, 71),
              origin: new google.maps.Point(0, 0),
              anchor: new google.maps.Point(17, 34),
              scaledSize: new google.maps.Size(25, 25)
            };

            // Membuat Marker untuk setiap tempat
            markersauto.push(new google.maps.Marker({
              map: map,
              icon: icon,
              title: place.name,
              position: place.geometry.location
            }));

            if (place.geometry.viewport) {
              bounds.union(place.geometry.viewport);
            } else {
              bounds.extend(place.geometry.location);
            }
          });
          map.fitBounds(bounds);
        });
    
        setMarkers(map, sites); // memanggil fungsi setMarker untuk menandai titik di peta.  
        setAction(map); //tambahan dari tutorial 2 untuk memanggil fungsi setAction(map);  
        infowindow = new google.maps.InfoWindow({  
            content: "loading..."  
          });  
    
        var bikeLayer = new google.maps.BicyclingLayer();  
        bikeLayer.setMap(map); //memnunculkan peta  
    }
        
    
    
    
    function setMarkers(map, markers) {  
         //berikut merupakan perulangan untuk membaca masing masing titik yang telah kita definisikan di sites[];  
        for (var i = 0; i < markers.length; i++) {  
          var sites = markers[i];  
          var siteLatLng = new google.maps.LatLng(sites[1], sites[2]);  
          var marker = new google.maps.Marker({  
            position: siteLatLng,  
            map: map,  
            title: sites[0],  
            zIndex: sites[3],  
            html: sites[4]  
    
          });  
    
          var contentString = "Some content";  
          // berikut merupakan fungsi untuk mengatur agar keterangan marker muncuk ketika mouse diarahkan ke marker (mouse over)  
          google.maps.event.addListener(marker, "mouseover", function () {  
              
            infowindow.setContent(this.html);  
            infowindow.open(map, this);  
          });  
        }  
    }  
    
      //-----------------------------------Tambahan1 dari tutorial 2 -----------------------------------------------  
    

    function setAction(map){ 
      google.maps.event.addListener(map, "rightclick", function(event) {  

          if(confirm("Tandai Titik Ini? (klik pada tanda yang muncul untuk melihat pilihan)")){  
            var lat = event.latLng.lat();  
            var lng = event.latLng.lng();
            var form = '<h4>Tambah Data</h4><form id="formtambahdata" method="post" action="<?php echo site_url('lokasi/add') ?>" enctype="multipart/form-data"><br><input class="form-control" type="text" id="nama" placeholder="Nama tempat" name="nama_lokasi"><br><input class="form-control" type="text" id="latitude" placeholder="Latitude" name="latitude" value="'+lat+'" readonly><br><input class="form-control" type="text" id="longitude" placeholder="Longitude" name="longitude" value="'+lng+'" readonly><br><input class="form-control" type="text" id="alamat" placeholder="Alamat" name="alamat"><br><input class="form-control" type="text" id="jumlah_lantai" placeholder="Jumlah Lantai" name="jumlah_lantai"><br><input class="form-control" type="text" id="kapasitas" placeholder="Kapasitas" name="kapasitas"><br><textarea id="keterangan" name="keterangan" placeholder="Isi Keterangan tempat" class="form-control"></textarea><br><input type="file" name="foto" class="form-control"><br><select name="id_kategori" class="form-control"><option value="NULL">Pilih Kategori</option><?php foreach ($kategori as $dt){?><option value="<?php echo $dt['id_kategori'] ?>"><?php echo $dt['nama_kategori'] ?></option><?php } ?></select><br><input type="submit" value="Simpan" name="simpan" class="btn btn-primary btn-sm"></form>';
              
            var siteLatLng = new google.maps.LatLng(lat, lng);  
            var marker = new google.maps.Marker({  
                position: siteLatLng,  
                map: map,  
                title: "add data",  
                zIndex: 100,  
                html: form  

              });  
             google.maps.event.addListener(marker, "mouseover", function () {  
                  
                infowindow.setContent(this.html);  
                infowindow.open(map, this);  
              });  

            }           
        });  
    }

google.maps.event.addDomListener(window, 'load', initialize);
google.maps.event.addDomListener(window, 'load', initAutocomplete);
</script>