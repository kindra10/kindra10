<?php
	$json = '{"shelter": [';

	
	// create looping dech array in fetch
	foreach ($lokasi as $row){

	// quotation marks (") are not allowed by the json string, we will replace it with the` character
	// strip_tag serves to remove html tags on strings
		$char ='"';

		$json .= 
		'{
			"id":"'.str_replace($char,'`',strip_tags($row['id_lokasi'])).'", 
			"nama":"'.str_replace($char,'`',strip_tags($row['nama_lokasi'])).'",
			"alamat":"'.str_replace($char,'`',strip_tags($row['alamat'])).'",
			"jumlah_lantai":"'.str_replace($char,'`',strip_tags($row['jumlah_lantai'])).'",
			"kapasitas":"'.str_replace($char,'`',strip_tags($row['kapasitas'])).'",
			"keterangan":"'.str_replace($char,'`',strip_tags($row['keterangan'])).'",
			"lat":"'.str_replace($char,'`',strip_tags($row['latitude'])).'",
			"lng":"'.str_replace($char,'`',strip_tags($row['longitude'])).'"
		},';
	}

	// omitted commas at the end of the array
	$json = substr($json,0,strlen($json)-1);

	$json .= ']}';

	// print json
	echo $json;
	
?>