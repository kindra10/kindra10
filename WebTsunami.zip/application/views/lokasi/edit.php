<div class="page-title">
	<div>
		<h1><i class="fa fa-edit"></i> Form Ubah Lokasi</h1>
		<ul class="breadcrumb side">
			<li><i class="fa fa-home fa-lg"></i></li>
			<li>Lokasi</li>
			<li class="active"><a href="#">Ubah</a></li>
		</ul>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="">
			<form method="POST" enctype="multipart/form-data" action="<?php echo site_url('lokasi/edit/').$lokasi['id_lokasi'] ?>">
				<h3 class="card-title">Ubah</h3>
				<div class="card-body">
					<div class="col-md-6">
						<div class="form-group">
							<label class="control-label">Nama Lokasi</label>
							<input class="form-control" type="text" name="nama_lokasi" placeholder="Nama Lokasi"
								value="<?php echo $lokasi['nama_lokasi'] ?>">
						</div>
					</div>
					<div class="col-md-3">
						<div class="form-group">
							<label class="control-label">Latitude</label>
							<input class="form-control" type="text" name="latitude" placeholder="0.190998"
								value="<?php echo $lokasi['latitude'] ?>" readonly>
						</div>
					</div>
					<div class="col-md-3">
						<div class="form-group">
							<label class="control-label">Longitude</label>
							<input class="form-control" type="text" name="longitude" placeholder="0.2189008"
								value="<?php echo $lokasi['longitude'] ?>" readonly>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="control-label">Alamat</label>
							<input class="form-control" type="text" name="alamat" placeholder="Alamat"
								value="<?php echo $lokasi['alamat'] ?>">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="control-label">Jumlah Lantai</label>
							<input class="form-control" type="text" name="jumlah_lantai" placeholder="Jumlah Lantai"
								value="<?php echo $lokasi['jumlah_lantai'] ?>">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="control-label">Kapasitas</label>
							<input class="form-control" type="text" name="kapasitas" placeholder="Kapasitas"
								value="<?php echo $lokasi['kapasitas'] ?>">
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label class="control-label">Keterangan</label>
							<textarea class="form-control" rows="4" name="keterangan"
								placeholder="Keterangan"><?php echo $lokasi['keterangan'] ?></textarea>
						</div>
					</div>
				    <div class="col-md-6">
						<div class="form-group">
							<label class="control-label">Gambar</label>
						<input class="form-control" type="file" name="gambar" value="<?php echo $lokasi['gambar'] ?>">
							<small>(Biarkan kosong jika tidak diganti)</small>
							<br>
							<img src="<?php echo site_url('public/images/').$lokasi['gambar'] ?>" width="250">
						</div>
					</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label class="control-label">Kategori</label>
							<select name="id_kategori" class="form-control">
								<?php $kt = $this->db->get_where('kategori',array('id_kategori'=>$lokasi['id_kategori']))->row_array(); ?>
								<option value="<?php echo $lokasi['id_kategori'] ?>"><?php echo $kt['nama_kategori'] ?>
								</option>
								<?php 
		                   		    foreach($kategori as $k){?>
								<option value="<?php echo $k['id_kategori'] ?>">
									<?php echo $k['nama_kategori'] ?></option>
								<?php }?>
							</select>
						</div>
					</div>
					<div class="col-md-12">
					<button class="btn btn-primary icon-btn" name="btnsimpan" type="submit"><i
							class="fa fa-fw fa-lg fa-check-circle"></i>Simpan</button>&nbsp;&nbsp;&nbsp;<a
						class="btn btn-default icon-btn" href="<?php echo site_url('lokasi') ?>"><i
							class="fa fa-fw fa-lg fa-times-circle"></i>Cancel</a>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
