<div class="page-title">
	<div>
		<h1>List Lokasi</h1>
		<ul class="breadcrumb side">
			<li><i class="fa fa-home fa-lg"></i></li>
			<li>lokasi</li>
			<li class="active"><a href="#">list</a></li>
		</ul>
	</div>

	<div>
		<a class="btn btn-default btn-flat" href="<?php echo site_url('lokasi/laporan') ?>">Cetak</a>
		<a class="btn btn-info btn-flat" href="<?php echo site_url('lokasi/add') ?>"><i class="fa fa-lg fa-map-marker"></i></a>
	</div>
</div>

<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-body">
			    <div class="table-responsive">
				<table class="table table-hover table-bordered" id="sampleTable">
					<thead>
						<tr>
							<td align="center">No</th>
							<td align="center">Nama Lokasi</td>
							<td align="center">Kategori</td>
							<td align="center">Latitude</tf>
							<td align="center">Longitude</td>
							<td align="center">Alamat</td>
							<td align="center">Jumlah Lantai</td>
							<td align="center">Kapasitas</td>
							<td align="center">Keterangan</td>
							<td align="center">Gambar</td>
							<td align="center"><i class="fa fa-cog fa-fw"></i></td>
						</tr>
					</thead>
					<tbody>
						<?php
						$i = 1;
						foreach ($lokasi as $data){ ?>
						<tr>
							<td align="center"><?php echo $i; ?></td>
							<td><?php echo $data['nama_lokasi']; ?></td>
							<td><?php $qry = $this->db->get_where('kategori',array('id_kategori'=>$data['id_kategori']))->row_array(); echo $qry['nama_kategori'] ?></td>
							<td><?php echo $data['latitude']; ?></td>
							<td><?php echo $data['longitude']; ?></td>
							<td><?php echo $data['alamat']; ?></td>
							<td><?php echo $data['jumlah_lantai']; ?></td>
							<td><?php echo $data['kapasitas']; ?></td>
							<td><?php echo $data['keterangan']; ?></td>
							<td><img src="<?php echo site_url('public/images/').$data['gambar'] ?>" width="100"></td>
							<td><a href="<?php echo site_url('lokasi/edit/').$data['id_lokasi'] ?>"
							    class="label label-success"><i class="fa fa-pencil-square-o"></i></a>
							    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							    <a onclick="if(confirm('Apakah anda yakin ingin menghapus data ini ??')){ location.href='<?php echo site_url('lokasi/remove/').$data['id_lokasi'] ?>' }"
								class="label label-danger"><i class="fa fa-trash-o fa-fw"></i></a>
							</td>
						</tr>
						<?php $i++; }?>
					</tbody>
				</table>
				</div>
			</div>
		</div>
	</div>
</div>
