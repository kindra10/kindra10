<?php

    $lat = $_GET['lat'];
	$lng = $_GET['lng'];	
	
	/* 10.0.2.2 adalah IP Address localhost EMULATOR ANDROID STUDIO,
        Ganti IP Address tersebut dengan IP Laptop Apabila di RUN di HP. HP dan Laptop harus 1 jaringan */
	$url = "https://shelter-tsunami.000webhostapp.com/public/images/";
	
	// perhitungan haversine formula pada sintak SQL
	$query = $this->db->query("SELECT id_lokasi, nama_lokasi, alamat, jumlah_lantai, kapasitas, keterangan, gambar, latitude, longitude, id_kategori, (6371 * ACOS(SIN(RADIANS(latitude)) * SIN(RADIANS($lat)) + COS(RADIANS(longitude - $lng)) * COS(RADIANS(latitude)) * COS(RADIANS($lat)))) AS jarak FROM tb_lokasi HAVING jarak < 6371 ORDER BY jarak ASC");
	
	$json = array();
	
	$no = 0;
	
	foreach($query as $row){
	    $sql = $this->db->query("SELECT * FROM tb_kategori WHERE id_kategori = '$row[id_kategori]'");
	    $data = mysqli_fetch_assoc($sql);
	    
		$json[$no]['id'] = $row['id_lokasi'];
		$json[$no]['nama'] = $row['nama_lokasi'];
		$json[$no]['alamat'] = $row['alamat'];
		$json[$no]['jumlah_lantai'] = $row['jumlah_lantai'];
		$json[$no]['kapasitas'] = $row['kapasitas'];
		$json[$no]['keterangan'] = $row['keterangan'];
		$json[$no]['gambar'] = $url.$row['gambar'];
		$json[$no]['latitude'] = $row['latitude'];
		$json[$no]['longitude'] = $row['longitude'];
		$json[$no]['jarak'] = $row['jarak'];
		$json[$no]['kategori'] = $data['nama_kategori'];
		
		$no++;
	}
	
	echo json_encode($json);
?>