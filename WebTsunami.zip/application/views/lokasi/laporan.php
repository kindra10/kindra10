<!DOCTYPE html>
<html>

<head>
	<title>GIS | Shelter Evakuasi Tsunami</title>
</head>

<body onload="window.print()">
	<table width="100%" align="center">
		<tr>
			<td width="125"><img src="<?php echo site_url('public/images/img/bpbd.jpeg') ?>" alt="" height="125"></td>
			<td align="center"><h1>BPBD Kota Padang</h1><br>Jl. Raya Padang By Pass Km 7 No. 15 <br>Kelurahan Pasar Ambacang Kota Padang 25152</td>
		</tr>
	</table>
	<hr>
	<h3 align="center">Daftar Shelter Evakuasi Tsunami Kota Padang</h3>
	<table align="center" width="100%" border="1" style="border-collapse: collapse;">
		<tr>
			<td><b>No.</td>
			<td><b>Nama Lokasi</td>
			<td><b>Kategori</td>
			<td><b>Latitude</td>
			<td><b>Longitude</td>
			<td><b>Alamat</td>
			<td><b>Jumlah Lantai</td>
			<td><b>Kapasitas</td>
			<td><b>Keterangan</td>
		</tr>
		<?php
	    $no = 1;
		foreach ($lokasi as $data) {
	?>
		<tr>
			<td><?php echo $no++ ?></td>
			<td><?php echo $data['nama_lokasi'] ?></td>
			<td><?php $qry = $this->db->get_where('kategori',array('id_kategori'=>$data['id_kategori']))->row_array(); echo $qry['nama_kategori'] ?></td>
			<td><?php echo $data['latitude'] ?></td>
			<td><?php echo $data['longitude'] ?></td>
			<td><?php echo $data['alamat'] ?></td>
			<td><?php echo $data['jumlah_lantai'] ?></td>
			<td><?php echo $data['kapasitas'] ?></td>
			<td><?php echo $data['keterangan'] ?></td>
		</tr>
		<?php } ?>
	</table><br><br><br>
	<table align="right">
		<tr>
			<td>Padang, <?php echo date('d-m-Y') ?></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td>...................................</td>
		</tr>
	</table>
</body>

</html>
