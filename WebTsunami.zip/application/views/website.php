<!doctype html>
<html lang="en">
  <head>  	
  	<meta charset="utf-8">
    <meta name="description" content="Responsive Bootstrap Landing Page Template">
    <meta name="keywords" content="Bootstrap, Landing page, Template, Registration, Landing">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="author" content="Grayrids">
		    <title>Shelter Tsunami</title>
    <link rel="shortcut icon"  href="<?php echo site_url('assets/img/favicon.png')?>">
    <link href="<?php echo site_url('public/css/bootstrap.min.css');?>" rel="stylesheet">
    <link href="<?php echo site_url('public/css/material.min.css');?>" rel="stylesheet">
    <link href="<?php echo site_url('public/css/main.css');?>" rel="stylesheet">
    <link href="<?php echo site_url('public/css/responsive.css');?>" rel="stylesheet">
    <link href="<?php echo site_url('public/css/animate.min.css');?>" rel="stylesheet">
  </head>
  <body>
  	<div class="content-wrap">
      <section id="why" class="section">
        <div class="container">
          <div class="row">
            <div class="col-md-6 col-sm-6 wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="300ms">
              <img src="<?php echo site_url('public/images/img/hp.png');?>" alt="">
            </div>
            <div class="col-md-6 col-sm-6 wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="300ms">
              <div class="pull-left content">
                <h2>
                  <br>Shelter Tsunami</h2>
                <p>Shelter Tsunami adalah aplikasi pemetaan shelter evakuasi tsunami di Kota Padang
                  <br>Aplikasi ini dibuat unttuk menyelesaikan Tugas Akhir di STMIK Jayanusa.
                  <br>
                </p>
                <ul class="list-item">
                  <li>
                    <i class="mdi-action-done"></i>Informasi berupa Lokasi, Gambar, Keterangan Lokasi</li>
                  <li>
                    <i class="mdi-action-done"></i>Rute Jalan Shelter Berdasarkan Lokasi</li>
                </ul>
                <a href="https://drive.google.com/file/d/16-wSEXy0br_rOiu0v2USR0D_4_gTx8KZ/view?usp=sharing" class="btn btn-lg btn-primary">Downoad Now!</a>
                <br><br><br><a href="https://drive.google.com/file/d/1gF2QOY5m2X_RxxpjrXRnnTPufqkmqHWw/view?usp=sharing">Cara Instalasi dan Cara memakainya</a>
              </div>
            </div>
          </div>
        </div>
      </section>
     <header class="hero-area" id="home">
      <div class="container">
          <div class="col-md-12">
            <div class="navbar navbar-inverse sticky-navigation navbar-fixed-top" role="navigation" data-spy="affix" data-offset-top="200">
              <div class="container">
                <div class="navbar-header">
                  <a class="logo-left " href="#"><i class="mdi-maps-place"></i>Shelter Tsunami</a>
                </div>
              </div>
            </div>
        </div>           
    </header>
    <section id="copyright">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <p class="copyright-text">
             © Gis Tsunami 2020 All right reserved. Designed and Developed by 
              <a href="https://web.facebook.com/indramuliarangkuti">
                Indra Mulia Rangkuti
              </a>
            </p>
          </div>
        </div>
      </div>
    </section>     
    </div>
    <script src="<?php echo site_url('public/js/jquery-2.1.4.min.js');?>"></script>
    <script src="<?php echo site_url('public/js/bootstrap.min.js');?>"></script>
    <script src="<?php echo site_url('public/js/material.min.js');?>"></script>
    <script src="<?php echo site_url('public/js/wow.js');?>"></script>
    <script src="<?php echo site_url('public/js/jquery.inview.min.js');?>"></script>
    <script src="<?php echo site_url('public/js/main.js');?>"></script>
    <script src="<?php echo site_url('public/js/classie.js');?>"></script>
    <script src="<?php echo site_url('public/js/jquery.nav.js');?>"></script>  
        <script>
        $(document).ready(function() {
            $.material.init();
        });
    </script>
  </body>
</html>