<?php 
	$server		= "localhost"; // adjust the server name
	$user		= "id17300969_admin"; // adjust the username
	$password	= "22101997Indr@"; // adjust the password
	$database	= "id17300969_tsunami"; // adjust the target databese
	
	$con = mysqli_connect($server, $user, $password, $database);
	if (mysqli_connect_errno()) {
		echo "Failed to connect MySQL: " . mysqli_connect_error();
	}

	$query = mysqli_query($con, "SELECT * FROM lokasi");
	
	$json = '{"shelter": [';

	
	// create looping dech array in fetch
	while ($row = mysqli_fetch_array($query)){

	// quotation marks (") are not allowed by the json string, we will replace it with the` character
	// strip_tag serves to remove html tags on strings
		$char ='"';

		$json .= 
		'{
			"id":"'.str_replace($char,'`',strip_tags($row['id_lokasi'])).'", 
			"nama":"'.str_replace($char,'`',strip_tags($row['nama_lokasi'])).'",
			"alamat":"'.str_replace($char,'`',strip_tags($row['alamat'])).'",
			"jumlah_lantai":"'.str_replace($char,'`',strip_tags($row['jumlah_lantai'])).'",
			"kapasitas":"'.str_replace($char,'`',strip_tags($row['kapasitas'])).'",
			"keterangan":"'.str_replace($char,'`',strip_tags($row['keterangan'])).'",
			"lat":"'.str_replace($char,'`',strip_tags($row['latitude'])).'",
			"lng":"'.str_replace($char,'`',strip_tags($row['longitude'])).'"
		},';
	}

	// omitted commas at the end of the array
	$json = substr($json,0,strlen($json)-1);

	$json .= ']}';

	// print json
	echo $json;
	
	mysqli_close($con);
	
?>