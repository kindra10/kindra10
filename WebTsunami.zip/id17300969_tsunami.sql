-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 03, 2021 at 07:19 AM
-- Server version: 10.5.12-MariaDB
-- PHP Version: 7.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id17300969_tsunami`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `nama`, `username`, `password`) VALUES
(1, 'admin', 'admin', 'ae8c09fb959e4289cc7169e00fd51f23a19292910bf58afdc6181a7612d9639f9a0cd3468705b66d0e855f2e7446897e50c669911f33067d0fb1c21373b69147gbPi6a8Ry6NrWYjspUv3PBikcTUDGGQ22wCo28j2sqo=');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Kantor'),
(2, 'Rumah Sakit'),
(4, 'Super Market'),
(5, 'Shelter'),
(6, 'Sekolah'),
(7, 'Kampus'),
(8, 'Tempat Ibadah');

-- --------------------------------------------------------

--
-- Table structure for table `lokasi`
--

CREATE TABLE `lokasi` (
  `id_lokasi` int(11) NOT NULL,
  `nama_lokasi` varchar(50) NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longitude` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `jumlah_lantai` int(11) NOT NULL,
  `kapasitas` varchar(11) NOT NULL,
  `keterangan` text NOT NULL,
  `gambar` text NOT NULL,
  `id_kategori` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lokasi`
--

INSERT INTO `lokasi` (`id_lokasi`, `nama_lokasi`, `latitude`, `longitude`, `alamat`, `jumlah_lantai`, `kapasitas`, `keterangan`, `gambar`, `id_kategori`) VALUES
(1, 'Bank Nagari Cabang Utama', '-0.9493619011364661', '100.35491555398463', 'Jalan Pemuda, Olo', 6, '1000', 'Gedung kantor yang bisa dijadikan shelter evakuasi tsunami', 'BankNagari.jpg', 1),
(2, 'Badan Pemeriksa Keuangan', '-0.9114878739060447', '100.35626272025509', 'Jl. Khatib Sulaiman, Ulak Karang', 4, '800', 'Gedung kantor yang bisa dijadikan shelter evakuasi tsunami', 'BPK-Sumbar.jpg', 1),
(3, 'Dinas Pengelolaan Sumber Daya Air', '-0.905055176512155', '100.3514128812481', 'Jl. Khatib Sulaiman, Ulak Karang', 3, '200', 'Gedung kantor yang bisa dijadikan shelter evakuasi tsunami', 'provsumbar.jpg', 1),
(4, 'Dewan Perwakilan Rakyat', '-0.9066851257861956', '100.3516271856167', 'Jalan Parman, Ulak Karang', 4, '100', 'Gedung kantor yang bisa dijadikan shelter evakuasi tsunami', 'dprdsumbar.jpg', 1),
(5, 'Polisi Daerah', '-0.9360751591531565', '100.36098955887816', 'Jl. Jenderal Sudirman, Padang Pasir', 8, '1500', 'Gedung kantor yang bisa dijadikan shelter evakuasi tsunami', 'poldasumbar.jpg', 1),
(6, 'Telkom Indonesia', '-0.9264496418495961', '100.36248733037395', 'Jl. Kyai Haji Ahmad Dahlan, Alai Parak Kopi', 7, '300', 'Gedung kantor yang bisa dijadikan shelter evakuasi tsunami', 'TelkomPadang.jpg', 1),
(7, 'PT. Sutan Kasim', '-0.940876768252903', '100.35463503804607', 'Jl. Veteran Jl. Bandar Purus, Purus', 4, '800', 'Gedung kantor yang bisa dijadikan shelter evakuasi tsunami', 'SutanKasim.jpg', 1),
(8, 'Rumah Sakit Yos Sudarso', '-0.9364618107452515', '100.36257232086679', 'Jl. Situjuh I, Jati Baru', 5, '300', 'Gedung rumah sakit yang bisa dijadikan shelter evakuasi tsunami', 'sudarsono.jpg', 2),
(9, 'Shelter Air Tawar Timur', '-0.9065787883866583', '100.34493661032755', 'Jl. Sumatera, Air Tawar Timur', 4, '200', 'Gedung Shelter yang didesain sebagai shelter', 'ShelterAirTawar.jpg', 5),
(10, 'Shelter Nurul Haq', '-0.8817881798236051', '100.34409073311788', 'Jl. Jondul, Parupuk Tabing', 6, '1000', 'Gedung Shelter yang didesain sebagai shelter', 'NurulHaq.jpg', 5),
(11, 'Shelter Darussalam', '-0.8682393726552926', '100.33953236070914', 'Jl. Parak Anau, Bungo Pasang', 6, '1000', 'Gedung Shelter yang didesain sebagai shelter', 'ShelterDarussalam1.jpg', 5),
(12, 'Sekolah Dasar Al-Azhar', '-0.909382510289675', '100.35499842591882', 'Jl. Khatib Sulaiman, Ulak Karang', 3, '1000', 'Gedung sekolah yang bisa dijadikan shelter evakuasi tsunami', 'Al-Azhar.jpg', 6),
(13, 'Sekolah Menengah Pertama Negeri 7', '-0.9209175693693817', '100.3514449714611', 'Jl. Parman, Lolong Belanti', 4, '2000', 'Gedung sekolah yang bisa dijadikan shelter evakuasi tsunami', 'SMP7.jpg', 6),
(14, 'Sekolah Menengah Atas Negeri 1', '-0.9196789549136494', '100.35371137977964', 'Jl. Belanti Raya, Lolong Belanti', 4, '2000', 'Gedung kantor yang bisa dijadikan shelter evakuasi tsunami', 'SMA1.jpg', 6),
(15, 'Universitas Negeri Padang', '-0.8969546893370726', '100.35068413954927', 'Jl. Hamka, Air Tawar', 5, '1500', 'Gedung kampus yang bisa dijadikan shelter evakuasi tsunami', 'FakultasIlmuPendidikan.jpg', 7),
(16, 'Universitas Bung Hatta', '-0.9066279677727568', '100.34379156653289', 'Jl. Bunda Raya, Ulak Karang Kampus', 6, '800', 'Gedung kampus yang bisa dijadikan shelter evakuasi tsunami', 'UniversitasBungHatta.jpg', 7),
(17, 'Universitas Eka Sakti', '-0.9382329725191962', '100.35598241655023', 'Jl. Veteran Dalam, Purus', 6, '800', 'Gedung kampus yang bisa dijadikan shelter evakuasi tsunami', 'EkaSakti.jpg', 7),
(18, 'Mesjid Raya', '-0.924541237933833', '100.36223043738775', 'Jl. Khatib Sulaiman', 2, '15000', 'Gedung tempat ibadah yang bisa dijadikan shelter evakuasi tsunami', 'masjid-raya-sumatera-barat.jpg', 8),
(19, 'Mesjid Taqwa Muhammadiyah', '-0.951792709002218', '100.35977511380634', 'Jl. Pasar Raya II, Kampung Jao', 4, '2500', 'Gedung tempat ibadah yang bisa dijadikan shelter evakuasi tsunami', 'Masjid_Taqwa_Muhammadiyah.jpg', 8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `lokasi`
--
ALTER TABLE `lokasi`
  ADD PRIMARY KEY (`id_lokasi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `lokasi`
--
ALTER TABLE `lokasi`
  MODIFY `id_lokasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
