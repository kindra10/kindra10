// $(function(){
//   var currencies = [
//     // { value: 'Zimbabwean dollar', data: 'ZWD' },
//    source: "search/autocomplete",
//       minLength: 1,
//   ];
  
//   // setup autocomplete function pulling from currencies[] array
//   $('#autocomplete').autocomplete({
//     lookup: currencies,
//     onSelect: function (suggestion) {
//       var thehtml = '<strong>Currency Name:</strong> ' + suggestion.value + ' <br> <strong>Symbol:</strong> ' + suggestion.data;
//       $('#outputcontent').html(thehtml);
//     }
//   });
  

// });
